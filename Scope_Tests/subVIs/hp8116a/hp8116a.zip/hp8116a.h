/*= HP 8116A Pulse/Function Generator Include File ========================*/
     
#ifndef __hp8116a_HEADER
#define __hp8116a_HEADER

#define PUBLIC __stdcall

#if defined (__cplusplus) || defined(__cplusplus__)
extern "C" {
#endif

/*=========================================================================*/
/*  Please note that the use of global variables or arrays in the Include  */
/*  file is no longer allowed.                                             */
/*=========================================================================*/

/*== GLOBAL CONSTANT DECLARATIONS =========================================*/
/* Replace 10 with the maximum number of devices of this type being used.  */
#define hp8116a_MAX_INSTR    10

/*== GLOBAL FUNCTION DECLARATIONS =========================================*/
short PUBLIC hp8116a_init (short GPIBAddress, short *instrumentID, short reset);
short PUBLIC hp8116a_init_wave (short instrumentID, short waveform, short dutyCycle,
                         double frequencyHz, double amplitudeV, double offsetV,
                         short enableOutput);
short PUBLIC hp8116a_init_trig_cont (short instrumentID, short triggerMode,
                              short triggerControl, short controlMode);
short PUBLIC hp8116a_set_disp (short instrumentID, short display);
short PUBLIC hp8116a_wave (short instrumentID, short waveform);
short PUBLIC hp8116a_time_param (short instrumentID, double frequencyHz, short dutyCycle,
                          double pulseWidthyS, short phase);
short PUBLIC hp8116a_lev_param (short instrumentID, short settingType, double amplitudeV,
                         double offsetV, double highLevelV, double lowLevelV);
short PUBLIC hp8116a_con_sweep (short instrumentID, double startFrequencyHz,
                         double stopFrequencyHz, double markerFreqHz,
                         double sweepTimeS);
short PUBLIC hp8116a_con_burst (short instrumentID, short burstNumber,
                         double repeatIntervalyS);
short PUBLIC hp8116a_set_out (short instrumentID, short selectControl,
                       short controlSetting);
short PUBLIC hp8116a_start_sweep_burst (short instrumentID, short functionType,
                                 short sweepBurstTrigger, short triggerType);
short PUBLIC hp8116a_trigger (short instrumentID);
short PUBLIC hp8116a_auto_vernier (short instrumentID, short autoVernier, short direction);
short PUBLIC hp8116a_read_prog_val (short instrumentID, short readValue, double *value);
short PUBLIC hp8116a_write (short instrumentID, char writeBuffer[]);
short PUBLIC hp8116a_read (short instrumentID, short numberBytesToRead, char readBuffer[],
                    short *numBytesRead);
short PUBLIC hp8116a_self_test (short instrumentID, short *passFailCode,
                         char selfTestMessage[]);
short PUBLIC hp8116a_reset (short instrumentID);
short PUBLIC hp8116a_error_query (short instrumentID, short *errorCode,
                           char errorMessage[]);
short PUBLIC hp8116a_revision_query (short instrumentID, char driverRevision[]);
short PUBLIC hp8116a_close (short instrumentID);

#if defined(__cplusplus) || defined(__cplusplus__)
}
#endif

/*****************************************************************************/
/*=== END INCLUDE FILE ======================================================*/
/*****************************************************************************/

#endif
