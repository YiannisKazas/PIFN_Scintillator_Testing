/***************************************************************************/
/* Copyright 1995 National Instruments Corporatation. All rights reserved. */
/***************************************************************************/

#include <gpib.h>
#include <formatio.h>
#include "hp8116a.h"

#define hp8116a_REVISION   "Rev 1.1, 1/96, CVI 3.1"

/*= HP8116A 50 MHz Pulse/Function Generator ===============================*/
/* LabWindows/CVI 3.1 Instrument Driver                                    */
/* Original Release: January 1995                                          */
/* By: GA, LWILDP, National Instruments, Austin, Texas                     */
/*     Ph (800) 433-3488    Fax (512) 794-5678                             */
/* Originally written in C                                                 */
/* Modification History:                                                   */
/*                                                                         */
/*    January 1996:   In the Application function Initialize Waveform,     */
/*                    changed the value of the fourth parameter in the     */
/*                    time_param function call from 0 to 0.008.            */
/*                    Also added code necessary for creation of DLL.       */
/*                    This change not done to the LW/DOS version.          */
/*                    Changed all datatypes that were ints to shorts or    */
/*                    longs and added [b2] or [b4] modifiers to all Format */
/*                    and Scan specifiers of type %d and %i. Also in the   */
/*                    CVI driver fp file changed all controls that were    */
/*                    ints to shorts or longs, this change was not possible*/
/*                    in the LW/DOS driver as the fp controls do not have  */
/*                    the datatype short and the default for an int in     */
/*                    LW/DOS is a short.                                   */
/*                    Modified by: JRO, NI, Austin TX.                     */
/*                    Phone (800) 433-3488  Fax (512) 794-5678             */    
/*                                                                         */
/*       June 1996:   Modified for MDLL compatibility.                     */
/*                    Modified by:  TKN, National Instruments              */
/*                                                                         */
/*                                                                         */
/*=========================================================================*/

/*= INSTRUMENT TABLE ======================================================*/
/* address array: contains the GPIB addresses of opened instruments.       */
/* bd array: contains the device descriptors returned by OpenDev.          */
/* instr_cnt: contains the number of instruments open of this model type.  */
/*=========================================================================*/
static short address[hp8116a_MAX_INSTR + 1];
static short bd[hp8116a_MAX_INSTR + 1];
static short instr_cnt;

/*= STATIC VARIABLES ======================================================*/
/* cmd is a buffer for GPIB I/O strings.                                   */
/* hp8116a_err: the error variable for the instrument module               */
/* ibcnt: contains the number of bytes transferred by GPIB reads and       */
/*        writes.  See the GPIB library I/O Class for more information     */
/*=========================================================================*/
static char cmd[100];
static short hp8116a_err;

static short wavetype[hp8116a_MAX_INSTR + 1];
static short triggermode[hp8116a_MAX_INSTR + 1];
static short controltype[hp8116a_MAX_INSTR + 1];
static short autovernier[hp8116a_MAX_INSTR + 1];
static short limitcheck[hp8116a_MAX_INSTR + 1];
static double hilimit[hp8116a_MAX_INSTR + 1];
static double lolimit[hp8116a_MAX_INSTR + 1];

/*= INSTRUMENT-DEPENDENT COMMAND ARRAYS ===================================*/
static char *atrig[8];
static char *atrigcon[3];
static char *aconmode[5];
static char *awave[5];
static char *aphase[2];
static char *avernier[2];
static char *avdirec[6];
static char *adisp[13];
static char *acontrol[3];

/*= UTILITY ROUTINES ======================================================*/
short hp8116a_open_instr (short, short *);
short hp8116a_close_instr (short);
short hp8116a_invalid_integer_range (short, short, short, short);
short hp8116a_invalid_real_range (double, double, double, short);
short hp8116a_device_closed (short);
short hp8116a_read_data (short, char *, short);
short hp8116a_write_data (short, char *, short);
short hp8116a_poll (short, char *);
short hp8116a_inst_clr (short);
short hp8116a_inst_trg (short);
short hp8116a_chk_mode (short, short, short, short);
short hp8116a_get_val (short, short, double *);
void hp8116a_setup_arrays (void);

/*=========================================================================*/
/* Function: Initialize                                                    */
/* Purpose:  This function opens the instrument, and initializes the       */
/*           instrument to a known state.                                  */
/*=========================================================================*/
short PUBLIC hp8116a_init (short addr, short *instrID, short rest)
{
    short ID;
    unsigned short listen;

    if (hp8116a_invalid_integer_range (addr, 0, 30, -1) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_integer_range (rest, 0, 1, -2) != 0)
        return hp8116a_err;
    if (hp8116a_open_instr (addr, &ID) != 0)
        return hp8116a_err;

    if (rest) {
        if (hp8116a_inst_clr (ID) != 0) {
            hp8116a_close_instr (ID);
            return hp8116a_err;
        }
        wavetype[ID] = 1;
        triggermode[ID] = 0;
        controltype[ID] = 0;
        autovernier[ID] = 0;
        limitcheck[ID] = 0;
    }

    if ((ibln(bd[ID], addr, 0, &listen) & 0x8000) == 0x8000) {
        hp8116a_close_instr(ID);
        hp8116a_err = 220;
        return hp8116a_err;
    }
    if (!listen) {
        hp8116a_close_instr(ID);
        hp8116a_err = 220;
        return hp8116a_err;
    }

    hp8116a_setup_arrays ();
    *instrID = ID;

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Initialize Wave                                               */
/* Purpose:  This function initializes the output of the instrument.       */
/*=========================================================================*/
short PUBLIC hp8116a_init_wave (short instrID, short wave, short duty, double freq,
                       double amp, double offs, short enable)
{
    if (hp8116a_invalid_integer_range (instrID, 1, hp8116a_MAX_INSTR, -1) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_integer_range (enable, 0, 1, -7) != 0)
        return hp8116a_err;
    if (hp8116a_device_closed(instrID) != 0)
        return hp8116a_err;

    if (hp8116a_auto_vernier (instrID, 0, 0) != 0)
        return hp8116a_err;
    if (hp8116a_init_trig_cont (instrID, 0, 0, 0) != 0)
        return hp8116a_err;

    if (hp8116a_time_param (instrID, freq, duty, 0.008, 0) != 0) {
        if (hp8116a_err == -2)
            hp8116a_err = -4;
        return hp8116a_err;
    }
    if (hp8116a_lev_param (instrID, 0, amp, offs, 0.5, -0.5) != 0) {
        if (hp8116a_err < -2)
            hp8116a_err = hp8116a_err - 2;
        return hp8116a_err;
    }
    if (hp8116a_wave (instrID, wave) != 0)
        return hp8116a_err;
    if (enable == 1)
        if (hp8116a_set_out (1, 2, 1) != 0)
            return hp8116a_err;

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Initialize Triggers and Controls                              */
/* Purpose:  This function sets the trigger type and the control modes.    */
/*=========================================================================*/
short PUBLIC hp8116a_init_trig_cont (short instrID, short tmode, short tcont, short control)
{
    double freq, repeat, burst;

    if (hp8116a_invalid_integer_range (instrID, 1, hp8116a_MAX_INSTR, -1) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_integer_range (tmode, 0, 7, -2) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_integer_range (tcont, 0, 2, -3) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_integer_range (control, 0, 4, -4) != 0)
        return hp8116a_err;
    if (hp8116a_device_closed(instrID) != 0)
        return hp8116a_err;

    if ((autovernier[instrID] == 1) && (tmode != 0)) {
        hp8116a_err = 306;
        return hp8116a_err;
    }

    if (hp8116a_chk_mode(instrID, wavetype[instrID], tmode, control) != 0)
        return hp8116a_err;

    if (tmode == 6) {
        if (hp8116a_get_val (instrID, 0, &freq) != 0)
            return hp8116a_err;
        if (hp8116a_get_val (instrID, 7, &burst) != 0)
            return hp8116a_err;
        if (hp8116a_get_val (instrID, 8, &repeat) != 0)
            return hp8116a_err;
        if (freq > 4.0e7) {
            hp8116a_err = 310;
            return hp8116a_err;
        }
        if ((burst * (1 / freq)) >= repeat) {
            hp8116a_err = 308;
            return hp8116a_err;
        }
    }

    if (tmode == 7) {
        if (hp8116a_get_val (instrID, 0, &freq) != 0)
            return hp8116a_err;
        if (freq > 4.0e7) {
            hp8116a_err = 310;
            return hp8116a_err;
        }
    }

    Fmt (cmd, "%s<%s%s%s", atrig[tmode], atrigcon[tcont], aconmode[control]);
    if (hp8116a_write_data (instrID, cmd, NumFmtdBytes()) != 0)
        return hp8116a_err;

    triggermode[instrID] = tmode;
    controltype[instrID] = control;

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Set Display                                                   */
/* Purpose:  This function sets what is displayed on the front panel.      */
/*=========================================================================*/
short PUBLIC hp8116a_set_disp (short instrID, short disp)
{
    char dummy;

    if (hp8116a_invalid_integer_range (instrID, 1, hp8116a_MAX_INSTR, -1) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_integer_range (disp, 0, 12, -2) != 0)
        return hp8116a_err;
    if (hp8116a_device_closed(instrID) != 0)
        return hp8116a_err;

    if (hp8116a_write_data (instrID, adisp[disp], 3) != 0)
        return hp8116a_err;
    if (hp8116a_poll (instrID, &dummy) != 0)
        return hp8116a_err;

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Set Waveform                                                  */
/* Purpose:  This function sets the type of wave produced.                 */
/*=========================================================================*/
short PUBLIC hp8116a_wave (short instrID, short wave)
{
    double freq, pwidth;

    if (hp8116a_invalid_integer_range (instrID, 1, hp8116a_MAX_INSTR, -1) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_integer_range (wave, 0, 4, -2) != 0)
        return hp8116a_err;
    if (hp8116a_device_closed(instrID) != 0)
        return hp8116a_err;
    if (hp8116a_chk_mode(instrID, wave, triggermode[instrID], controltype[instrID]) != 0)
        return hp8116a_err;

    if (wave == 4) {
        if (hp8116a_get_val (instrID, 6, &pwidth) != 0)
            return hp8116a_err;
        if (hp8116a_get_val (instrID, 0, &freq) != 0)
            return hp8116a_err;
        if ((pwidth + pwidth / 100) > (1 / freq)) {
            hp8116a_err = 307;
            return hp8116a_err;
        }
    }

    Fmt (cmd, "%s<%s", awave[wave]);
    if (hp8116a_write_data (instrID, cmd, NumFmtdBytes()) != 0)
        return hp8116a_err;
    wavetype[instrID] = wave;

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Set Timing Parameters                                         */
/* Purpose:  This function sets timing parameters such as frequency.       */
/*=========================================================================*/
short PUBLIC hp8116a_time_param (short instrID, double freq, short duty, double pwidth, short phase)
{
    double lfreq;

    if (hp8116a_invalid_integer_range (instrID, 1, hp8116a_MAX_INSTR, -1) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_real_range (freq, 0.001, 5.0e7, -2) != 0)
        return hp8116a_err;
    if (freq < 1.0e7) {
        if (hp8116a_invalid_integer_range (duty, 10, 90, -3) != 0)
            return hp8116a_err;
    }
    else
        if (hp8116a_invalid_integer_range (duty, 20, 80, -3) != 0)
            return hp8116a_err;
    if (hp8116a_invalid_real_range (pwidth, 0.008, 999000.0, -4) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_integer_range (phase, 0, 1, -5) != 0)
        return hp8116a_err;
    if (hp8116a_device_closed(instrID) != 0)
        return hp8116a_err;

    if ((freq >= 1.0e7) && (duty != 50)) {
        hp8116a_err = -3;
        return hp8116a_err;
    }

    if ((triggermode[instrID] >= 6) && (freq > 4.0e7)) {
        hp8116a_err = 310;
        return hp8116a_err;
    }

    if (wavetype[instrID] == 4) {
        if (((pwidth + pwidth / 100) / 1e6) > (1 / freq)) {
            hp8116a_err = 307;
            return hp8116a_err;
        }
    }

    if (hp8116a_get_val (instrID, 0, &lfreq) != 0)
        return hp8116a_err;
    if (lfreq < freq) {
        Fmt (cmd, "%s<DTY %d[b2]%%", duty);
        if (hp8116a_write_data (instrID, cmd, NumFmtdBytes()) != 0)
            return hp8116a_err;
    }
    Fmt (cmd, "%s<FRQ %fHZ WID %fUS %s", freq, pwidth, aphase[phase]);
    if (hp8116a_write_data (instrID, cmd, NumFmtdBytes()) != 0)
        return hp8116a_err;
    if (lfreq >= freq) {
        Fmt (cmd, "%s<DTY %d[b2]%%", duty);
        if (hp8116a_write_data (instrID, cmd, NumFmtdBytes()) != 0)
            return hp8116a_err;
    }

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Set Level Parameters                                          */
/* Purpose:  This function sets level parameters such as amplitude.        */
/*=========================================================================*/
short PUBLIC hp8116a_lev_param (short instrID, short settype, double amp, double offset,
                       double hilev, double lowlev)
{
    double temp;

    if (hp8116a_invalid_integer_range (instrID, 1, hp8116a_MAX_INSTR, -1) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_integer_range (settype, 0, 1, -2) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_real_range (amp, 0.01, 16.00, -3) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_real_range (offset, -7.95, 7.95, -4) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_real_range (hilev, -8.00, 8.00, -5) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_real_range (lowlev, -8.00, 8.00, -6) != 0)
        return hp8116a_err;
    if (hp8116a_device_closed(instrID) != 0)
        return hp8116a_err;

    if (settype == 0) {
        if (offset < 0)
            temp = -offset;
        else
            temp = offset;
        if (((2*temp) + amp) > 16.0) {
            hp8116a_err = 301;
            return hp8116a_err;
        }
        hilev = amp/2 + offset;
        lowlev = -amp/2 + offset;
        Fmt(cmd,"%s<AMP %fV OFS %fV", amp, offset);
    }
    else {
        if (lowlev > hilev) {
            hp8116a_err = 302;
            return hp8116a_err;
        }
        Fmt(cmd,"%s<HIL %fV LOL %fV", hilev, lowlev);
    }

    if ((limitcheck[instrID] == 1) && ((hilev > hilimit[instrID]) || (lowlev < lolimit[instrID]))) {
        hp8116a_err = 309;
        return hp8116a_err;
    }

    if (hp8116a_write_data (instrID, cmd, NumFmtdBytes()) != 0)
        return hp8116a_err;

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Configure Sweep                                               */
/* Purpose:  This function sets the values used for a logarithmic sweep.   */
/*=========================================================================*/
short PUBLIC hp8116a_con_sweep (short instrID, double start, double stop, double mark, double time)
{
    if (hp8116a_invalid_integer_range (instrID, 1, hp8116a_MAX_INSTR, -1) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_real_range (start, 0.001, 5.0e7, -2) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_real_range (stop, 0.001, 5.0e7, -3) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_real_range (mark, 0.001, 5.0e7, -4) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_real_range (time, 0.01, 999.0, -5) != 0)
        return hp8116a_err;
    if (hp8116a_device_closed(instrID) != 0)
        return hp8116a_err;

    if (start > stop) {
        hp8116a_err = 303;
        return hp8116a_err;
    }
    if ((mark < start) || (mark > stop)) {
        hp8116a_err = 304;
        return hp8116a_err;
    }

    Fmt(cmd, "%s<STA %fHZ STP %fHZ MRK %fHZ SWT %fS", start, stop, mark, time);
    if (hp8116a_write_data (instrID, cmd, NumFmtdBytes()) != 0)
        return hp8116a_err;

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Configure Burst                                               */
/* Purpose:  This function sets the values used for the burst mode.        */
/*=========================================================================*/
short PUBLIC hp8116a_con_burst (short instrID, short num, double rpt)
{
    double freq;

    if (hp8116a_invalid_integer_range (instrID, 1, hp8116a_MAX_INSTR, -1) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_integer_range (num, 1, 1999, -2) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_real_range (rpt, 0.01, 999000.0, -3) != 0)
        return hp8116a_err;
    if (hp8116a_device_closed(instrID) != 0)
        return hp8116a_err;

    if (triggermode[instrID] == 6) {
        if (hp8116a_get_val (instrID, 0, &freq) != 0)
            return hp8116a_err;
        if ((num * (1 / freq)) > (rpt / 1e6)) {
            hp8116a_err = 308;
            return hp8116a_err;
        }
    }

    Fmt(cmd, "%s<BUR %d[b2]# RPT %fUS", num, rpt);
    if (hp8116a_write_data (instrID, cmd, NumFmtdBytes()) != 0)
        return hp8116a_err;

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Set Output Controls                                           */
/* Purpose:  This function sets output controls such as Complement.        */
/*=========================================================================*/
short PUBLIC hp8116a_set_out (short instrID, short control, short onoff)
{
    if (hp8116a_invalid_integer_range (instrID, 1, hp8116a_MAX_INSTR, -1) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_integer_range (control, 0, 2, -2) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_integer_range (onoff, 0, 1, -3) != 0)
        return hp8116a_err;
    if (hp8116a_device_closed(instrID) != 0)
        return hp8116a_err;

    if (control == 2)
        onoff = onoff ^ 1;
    Fmt(cmd, "%s<%s%d[b2]", acontrol[control], onoff);
    if (hp8116a_write_data (instrID, cmd, NumFmtdBytes()) != 0)
        return hp8116a_err;

    if (control == 0) {
        limitcheck[instrID] = onoff;
        if (onoff == 1) {
            if (hp8116a_get_val (instrID, 4, &hilimit[instrID]) != 0)
                return hp8116a_err;
            if (hp8116a_get_val (instrID, 5, &lolimit[instrID]) != 0)
                return hp8116a_err;
        }
    }

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Start Sweep/Burst                                             */
/* Purpose:  This function starts the logarithmic frequency sweep or burst */
/*           mode.                                                         */
/*=========================================================================*/
short PUBLIC hp8116a_start_sweep_burst (short instrID, short ftype, short ttype, short trig)
{
    double freq, burst, repeat;

    if (hp8116a_invalid_integer_range (instrID, 1, hp8116a_MAX_INSTR, -1) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_integer_range (ftype, 0, 1, -2) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_integer_range (ttype, 0, 1, -3) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_integer_range (trig, 0, 1, -4) != 0)
        return hp8116a_err;
    if (hp8116a_device_closed(instrID) != 0)
        return hp8116a_err;

    if (autovernier[instrID] == 1) {
        hp8116a_err = 306;
        return hp8116a_err;
    }

    if (ftype == 1) {
        if (hp8116a_chk_mode(instrID, wavetype[instrID], ttype+4, controltype[instrID]) != 0)
            return hp8116a_err;
        Fmt(cmd, "%s<%s", atrig[ttype+4]);
        if (hp8116a_write_data (instrID, cmd, NumFmtdBytes()) != 0)
            return hp8116a_err;
    }
    else {
        if (hp8116a_chk_mode(instrID, wavetype[instrID], ttype+6, controltype[instrID]) != 0)
            return hp8116a_err;
        if (ttype == 0) {
            if (hp8116a_get_val (instrID, 0, &freq) != 0)
                return hp8116a_err;
            if (hp8116a_get_val (instrID, 7, &burst) != 0)
                return hp8116a_err;
            if (hp8116a_get_val (instrID, 8, &repeat) != 0)
                return hp8116a_err;
            if (freq > 4.0e7) {
                hp8116a_err = 310;
                return hp8116a_err;
            }
            if ((burst * (1 / freq)) >= repeat) {
                hp8116a_err = 308;
                return hp8116a_err;
            }
        }
        else {
            if (hp8116a_get_val (instrID, 0, &freq) != 0)
                return hp8116a_err;
            if (freq > 4.0e7) {
                hp8116a_err = 310;
                return hp8116a_err;
            }
        }
        Fmt(cmd, "%s<%s", atrig[ttype+6]);
        if (hp8116a_write_data (instrID, cmd, NumFmtdBytes()) != 0)
            return hp8116a_err;
    }

    if ((trig == 1) && (ttype == 1))
        if (hp8116a_inst_trg(instrID) != 0)
            return hp8116a_err;

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Trigger                                                       */
/* Purpose:  This function triggers the instrument.                        */
/*=========================================================================*/
short PUBLIC hp8116a_trigger (short instrID)
{
    if (hp8116a_invalid_integer_range (instrID, 1, hp8116a_MAX_INSTR, -1) != 0)
        return hp8116a_err;
    if (hp8116a_device_closed(instrID) != 0)
        return hp8116a_err;

    if (hp8116a_inst_trg (instrID) != 0)
        return hp8116a_err;

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Auto Vernier                                                  */
/* Purpose:  This function starts the auto vernier option.                 */
/*=========================================================================*/
short PUBLIC hp8116a_auto_vernier (short instrID, short vernier, short dir)
{
    if (hp8116a_invalid_integer_range (instrID, 1, hp8116a_MAX_INSTR, -1) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_integer_range (vernier, 0, 1, -2) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_integer_range (dir, 0, 5, -3) != 0)
        return hp8116a_err;
    if (hp8116a_device_closed(instrID) != 0)
        return hp8116a_err;

    if (triggermode[instrID] != 0) {
        hp8116a_err = 305;
        return hp8116a_err;
    }

    if (vernier == 1)
        Fmt(cmd, "%s<%s%s", avernier[vernier], avdirec[dir]);
    else
        Fmt(cmd, "%s<%s", avernier[vernier]);
    if (hp8116a_write_data (instrID, cmd, NumFmtdBytes()) != 0)
        return hp8116a_err;

    autovernier[instrID] = vernier;

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Read Programmed Value                                         */
/* Purpose:  This function returns the value specified by rtype.           */
/*=========================================================================*/
short PUBLIC hp8116a_read_prog_val (short instrID, short rtype, double *retval)
{
    double result, mult;
    char units[10];

    if (hp8116a_invalid_integer_range (instrID, 1, hp8116a_MAX_INSTR, -1) != 0)
        return hp8116a_err;
    if (hp8116a_invalid_integer_range (rtype, 0, 12, -2) != 0)
        return hp8116a_err;
    if (hp8116a_device_closed(instrID) != 0)
        return hp8116a_err;

    if (hp8116a_get_val (instrID, rtype, retval) != 0)
        return hp8116a_err;

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Write To Instrument                                           */
/* Purpose:  This function writes a command string to the instrument.      */
/*=========================================================================*/
short PUBLIC hp8116a_write (short instrID, char cmd_string[])
{
    if (hp8116a_invalid_integer_range (instrID, 1, hp8116a_MAX_INSTR, -1) != 0)
        return hp8116a_err;
    if (hp8116a_device_closed(instrID) != 0)
        return hp8116a_err;

    Fmt (cmd, "%s<%s", cmd_string);
    if (hp8116a_write_data (instrID, cmd, NumFmtdBytes()) != 0)
        return hp8116a_err;

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Read Instrument Buffer                                        */
/* Purpose:  This function reads the output buffer of the instrument.      */
/*=========================================================================*/
short PUBLIC hp8116a_read (short instrID, short numbytes, char in_buff[], short *bytes_read)
{
    if (hp8116a_invalid_integer_range (instrID, 1, hp8116a_MAX_INSTR, -1) != 0)
        return hp8116a_err;
    if (hp8116a_device_closed(instrID) != 0)
        return hp8116a_err;

    *bytes_read = 0;
    if (hp8116a_read_data (instrID, in_buff, numbytes) != 0)
        return hp8116a_err;

    *bytes_read = ibcnt;

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Reset                                                         */
/* Purpose:  This function resets the instrument.                          */
/*=========================================================================*/
short PUBLIC hp8116a_reset (short instrID)
{
    if (hp8116a_invalid_integer_range (instrID, 1, hp8116a_MAX_INSTR, -1) != 0)
        return hp8116a_err;
    if (hp8116a_device_closed(instrID) != 0)
        return hp8116a_err;

    if (hp8116a_inst_clr (instrID) != 0)
        return hp8116a_err;

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Self-Test                                                     */
/* Purpose:  This function executes the instrument self-test and returns   */
/* the result.                                                             */
/*=========================================================================*/
short PUBLIC hp8116a_self_test (short instrID, short *test_result, char test_message[])
{
    char test_char;
    short test_int;

    if (hp8116a_invalid_integer_range (instrID, 1, hp8116a_MAX_INSTR, -1) != 0)
        return hp8116a_err;
    if (hp8116a_device_closed(instrID) != 0)
        return hp8116a_err;

    if (hp8116a_write_data (instrID, "EST IERR", 8) != 0)
        return hp8116a_err;
    if (hp8116a_read_data (instrID, test_message, 50) != 0)
        return hp8116a_err;
    if (hp8116a_poll (instrID, &test_char) != 0)
        return hp8116a_err;
    test_int = (short) test_char;
    *test_result = test_int;

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Error Query                                                   */
/* Purpose:  This function queries the instrument error queue.             */
/*=========================================================================*/
short PUBLIC hp8116a_error_query (short instrID, short *error, char error_message[])
{
    char error_char;
    short error_int;

    if (hp8116a_invalid_integer_range (instrID, 1, hp8116a_MAX_INSTR, -1) != 0)
        return hp8116a_err;
    if (hp8116a_device_closed(instrID) != 0)
        return hp8116a_err;

    if (hp8116a_poll (instrID, &error_char) != 0)
        return hp8116a_err;
    error_int = (short) error_char;
    *error = error_int;
    if (hp8116a_write_data (instrID, "IERR", 4) != 0)
        return hp8116a_err;
    if (hp8116a_read_data (instrID, error_message, 100) != 0)
        return hp8116a_err;

    *error = *error & 0x000F;

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Revision                                                      */
/* Purpose:  This function returns the driver revision.                    */
/*=========================================================================*/
short PUBLIC hp8116a_revision_query (short instrID, char driver_rev[])
{
    if (hp8116a_invalid_integer_range (instrID, 1, hp8116a_MAX_INSTR, -1) != 0)
        return hp8116a_err;
    if (hp8116a_device_closed(instrID) != 0)
        return hp8116a_err;

    Fmt (driver_rev, "%s<%s", hp8116a_REVISION);

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Close                                                         */
/* Purpose:  This function closes the instrument.                          */
/*=========================================================================*/
short PUBLIC hp8116a_close (short instrID)
{
    if (hp8116a_invalid_integer_range (instrID, 1, hp8116a_MAX_INSTR, -1) != 0)
        return hp8116a_err;
    if (hp8116a_device_closed (instrID))
        return hp8116a_err;

    hp8116a_close_instr (instrID);

    return hp8116a_err;
}

/*= UTILITY ROUTINES ======================================================*/

/*=========================================================================*/
/* Function: Open Instrument                                               */
/* Purpose:  This function locates and initializes an entry in the         */
/*           Instrument Table and the GPIB device table for the            */
/*           instrument.  The size of the Instrument Table can be changed  */
/*           in the include file by altering the constant                  */
/*           hp8116a_MAX_INSTR.  The return value of this function is equal */
/*           to the global error variable.                                 */
/*=========================================================================*/
short hp8116a_open_instr (short addr, short *ID)
{
    short i, instrID;

    instrID = 0;
    hp8116a_err = 0;

/* Check to see if the instrument is already in the Instrument Table. */

    for (i = 1; i <= hp8116a_MAX_INSTR; i++)
        if (address[i] == addr) {
            instrID = i;
            i = hp8116a_MAX_INSTR;
         }

/* If it is not in the instrument table, open an entry for the instrument. */

    if (instrID <= 0)
        for (i = 1; i <= hp8116a_MAX_INSTR; i++)
            if (address[i] == 0) {
                instrID = i;
                i = hp8116a_MAX_INSTR;
             }

/* If an entry could not be opened in the Instrument Table, return an error.*/

    if (instrID <= 0) {
        hp8116a_err = 220;
        return hp8116a_err;
    }

/* If the device has not been opened in the GPIB device table (bd[ID] = 0),*/
/*  then open it.                                                          */

    if (bd[instrID] <= 0) {
        if (instr_cnt <= 0)
            CloseInstrDevs("hp8116a");
        bd[instrID] = OpenDev ("", "hp8116a");
        if (bd[instrID] <= 0) {
            hp8116a_err = 220;
            return hp8116a_err;
        }
        instr_cnt += 1;
        address[instrID] = addr;
     }

/*  Change the primary address of the device    */

    if (ibpad (bd[instrID], addr) & 0x8000) {
        hp8116a_err = 233;
        return hp8116a_err;
    }

    *ID = instrID;
    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Close Instrument                                              */
/* Purpose:  This function closes the instrument by removing it from the   */
/*           GPIB device table and setting the address and bd[instrID] to  */
/*           zero in the Instrument Table.  The return value is equal to   */
/*           the global error variable.                                    */
/*=========================================================================*/
short hp8116a_close_instr (short instrID)
{
    if (bd[instrID] != 0) {
        CloseDev (bd[instrID]);
        bd[instrID] = 0;
        address[instrID] = 0;
        instr_cnt -= 1;
    }
    else
        hp8116a_err = 221;

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Invalid Integer Range                                         */
/* Purpose:  This function checks an integer to see if it lies between a   */
/*           minimum and maximum value.  If the value is out of range, set */
/*           the global error variable to the value err_code.  If the      */
/*           value is OK, error = 0.  The return value is equal to the     */
/*           global error value.                                           */
/*=========================================================================*/
short hp8116a_invalid_integer_range (short val, short min, short max, short err_code)
{
    if (val < min || val > max)
        hp8116a_err = err_code;
    else
        hp8116a_err = 0;

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Invalid Real Range                                            */
/* Purpose:  This function checks a real number to see if it lies between  */
/*           a minimum and maximum value.  If the value is out of range,   */
/*           set the global error variable to the value err_code.  If the  */
/*           value is OK, error = 0.  The return value is equal to the     */
/*           global error value.                                           */
/*=========================================================================*/
short hp8116a_invalid_real_range (double val, double min, double max, short err_code)
{
    if (val < min || val > max)
        hp8116a_err = err_code;
    else
        hp8116a_err = 0;

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Device Closed                                                 */
/* Purpose:  This function checks to see if the module has been            */
/*           initialized.  If the device has not been opened, set the      */
/*           global error variable to 232, 0 otherwise. The return value   */
/*           is equal to the global error value.                           */
/*=========================================================================*/
short hp8116a_device_closed (short instrID)
{
    if (bd[instrID] <= 0)
        hp8116a_err = 232;
    else
        hp8116a_err = 0;

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Read Data                                                     */
/* Purpose:  This function reads a buffer of data from the instrument. The */
/*           return value is equal to the global error variable.           */
/*=========================================================================*/
short hp8116a_read_data (short instrID, char *buf, short cnt)
{
    if (ibrd(bd[instrID], buf, (long)cnt) & 0x8000)
        hp8116a_err = 231;
    else
        hp8116a_err = 0;

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Write Data                                                    */
/* Purpose:  This function writes a buffer of data to the instrument. The  */
/*           return value is equal to the global error variable.           */
/*=========================================================================*/
short hp8116a_write_data (short instrID, char *buf, short cnt)
{
    if (ibwrt(bd[instrID], buf, (long)cnt) & 0x8000)
        hp8116a_err = 230;
    else
        hp8116a_err = 0;

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Serial Poll                                                   */
/* Purpose:  This function performs a serial poll on the instrument.       */
/*           The status byte of the instrument is placed in the response   */
/*           variable. The return value is equal to the global error       */
/*           variable.                                                     */
/*=========================================================================*/
short hp8116a_poll (short instrID, char *response)
{
    if (ibrsp (bd[instrID], response) & 0x8000)
        hp8116a_err = 226;
    else
        hp8116a_err = 0;

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Instrument Clear                                              */
/* Purpose:  This function returns the instrument to its standard          */
/*           parameter set.                                                */
/*=========================================================================*/
short hp8116a_inst_clr (short instrID)
{
    if (ibclr(bd[instrID]) & 0x8000)
        hp8116a_err = 224;
    else
        hp8116a_err = 0;

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Instrument Trigger                                            */
/* Purpose:  This function triggers the instrument.                        */
/*=========================================================================*/
short hp8116a_inst_trg (short instrID)
{
    if (ibtrg(bd[instrID]) & 0x8000)
        hp8116a_err = 225;
    else
        hp8116a_err = 0;

    return hp8116a_err;
}


/*=========================================================================*/
/* Function: Check Mode                                                    */
/* Purpose:  This function checks that the combination of trigger mode,    */
/*           control mode, and waveform are valid.                         */
/*=========================================================================*/
short hp8116a_chk_mode (short instrID, short wave, short trig, short control)
{
    if ((control == 0) && (((trig == 3) && (wave != 4)) || ((trig == 6) && (wave == 4)))) {
        hp8116a_err = 300;
        return hp8116a_err;      /* No control mode */
    }
    if ((control == 1) && ((trig == 3) || ((trig == 6) && (wave == 4)))) {
        hp8116a_err = 300;
        return hp8116a_err;      /* Frequency Modulation */
    }
    if ((control == 2) && (((trig == 3) && (wave != 4)) || ((trig == 6) && (wave == 4)))) {
        hp8116a_err = 300;
        return hp8116a_err;      /* Amplitude Modulation */
    }
    if ((control == 3) && ((trig == 3) || (trig == 6) || (wave != 4))) {
        hp8116a_err = 300;
        return hp8116a_err;      /* Pulse Width Modulation */
    }
    if ((control == 4) && ((trig == 3) || (trig == 4) || (trig == 5) || ((trig == 6) && (wave == 4)))) {
        hp8116a_err = 300;
        return hp8116a_err;      /* Voltage Control Oscillation */
    }

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Get Value                                                     */
/* Purpose:  This function returns the value specified by rtype.           */
/*=========================================================================*/
short hp8116a_get_val (short instrID, short rtype, double *retval)
{
    double result, mult;
    char units[10];

    Fmt(cmd, "%s<I%s", adisp[rtype]);
    if (hp8116a_write_data(instrID, cmd, NumFmtdBytes()) != 0)
        return hp8116a_err;
    if (hp8116a_read_data(instrID, cmd, 12) != 0)
        return hp8116a_err;
    if (Scan(cmd, "%s[i4]>%f%s", &result, units) != 2) {
        hp8116a_err = 236;
        return hp8116a_err;
    }

    mult = 0.0;
    if ((rtype == 0) || ((rtype >= 9) && (rtype <=11))) {
        if (mult == 0.0) {
            Scan(units, "MZ");
            if (NumFmtdBytes() == 2)
                mult = 0.001;
        }
        if (mult == 0.0) {
            Scan(units, "HZ");
            if (NumFmtdBytes() == 2)
                mult = 1.0;
        }
        if (mult == 0.0) {
            Scan(units, "KHZ");
            if (NumFmtdBytes() == 3)
                mult = 1000.0;
        }
        if (mult == 0.0) {
            Scan(units, "MHZ");
            if (NumFmtdBytes() == 3)
                mult = 1.0e6;
        }
    }

    if ((rtype >= 2) && (rtype <= 5)) {
        if (mult == 0.0) {
            Scan(units, "V");
            if (NumFmtdBytes() == 1)
                mult = 1.0;
        }
        if (mult == 0.0) {
            Scan(units, "MV");
            if (NumFmtdBytes() == 2)
                mult = 0.001;
        }
    }

    if ((rtype == 6) || (rtype == 8) || (rtype == 12)) {
        if (mult == 0.0) {
            Scan(units, "NS");
            if (NumFmtdBytes() == 2)
                mult = 1.0e-9;
        }
        if (mult == 0.0) {
            Scan(units, "US");
            if (NumFmtdBytes() == 2)
                mult = 1.0e-6;
        }
        if (mult == 0.0) {
            Scan(units, "MS");
            if (NumFmtdBytes() == 2)
                mult = 1.0e-3;
        }
        if (mult == 0.0) {
            Scan(units, "S");
            if (NumFmtdBytes() == 1)
                mult = 1.0;
        }
    }

    if ((rtype == 1) || (rtype == 7))
        mult = 1.0;

    if (mult == 0.0) {
        hp8116a_err = 236;
        return hp8116a_err;
    }

    *retval = result * mult;

    return hp8116a_err;
}

/*=========================================================================*/
/* Function: Setup Arrays                                                  */
/* Purpose:  This function is called by the init routine to initialize     */
/*           static arrays.                                                */
/*=========================================================================*/
void hp8116a_setup_arrays ()
{
    atrig[0] = "M1 ";
    atrig[1] = "M2 ";
    atrig[2] = "M3 ";
    atrig[3] = "M4 ";
    atrig[4] = "M5 ";
    atrig[5] = "M6 ";
    atrig[6] = "M7 ";
    atrig[7] = "M8 ";

    atrigcon[0] = "T0 ";
    atrigcon[1] = "T1 ";
    atrigcon[2] = "T2 ";

    aconmode[0] = "CT0 ";
    aconmode[1] = "CT1 ";
    aconmode[2] = "CT2 ";
    aconmode[3] = "CT3 ";
    aconmode[4] = "CT4 ";

    awave[0] = "W0 ";
    awave[1] = "W1 ";
    awave[2] = "W2 ";
    awave[3] = "W3 ";
    awave[4] = "W4 ";

    aphase[0] = "H0 ";
    aphase[1] = "H1 ";

    avernier[0] = "A0 ";
    avernier[1] = "A1 ";

    avdirec[0] = "MU ";
    avdirec[1] = "SU ";
    avdirec[2] = "LU ";
    avdirec[3] = "MD ";
    avdirec[4] = "SD ";
    avdirec[5] = "LD ";

    adisp[0] = "FRQ";
    adisp[1] = "DTY";
    adisp[2] = "AMP";
    adisp[3] = "OFS";
    adisp[4] = "HIL";
    adisp[5] = "LOL";
    adisp[6] = "WID";
    adisp[7] = "BUR";
    adisp[8] = "RPT";
    adisp[9] = "STA";
    adisp[10] = "STP";
    adisp[11] = "MRK";
    adisp[12] = "SWT";

    acontrol[0] = "L";
    acontrol[1] = "C";
    acontrol[2] = "D";
}

/*=== THE END =============================================================*/
